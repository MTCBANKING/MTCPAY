/// High-level API client abstraction for MTCPAY.
///
/// This file is intentionally minimal: integrate it with your
/// EMI / payment provider (e.g. Walletto, Moka, etc.) by mapping
/// each method to the partner REST / gRPC APIs.
class ApiClient {
  Future<String> loginWithPhone(String phoneNumber) async {
    // TODO: Implement login / OTP request.
    return 'mock-token';
  }

  Future<double> getWalletBalance() async {
    // TODO: Call /wallet/balance endpoint.
    return 1250.00;
  }

  Future<List<Map<String, dynamic>>> getCards() async {
    // TODO: Call /cards endpoint.
    return [
      {
        'label': 'MTCPAY Virtual',
        'last4': '1234',
        'status': 'active',
      },
      {
        'label': 'MTCPAY Physical',
        'last4': '5678',
        'status': 'active',
      },
    ];
  }

  Future<List<Map<String, dynamic>>> getTransactions() async {
    // TODO: Call /transactions endpoint.
    return [
      {
        'title': 'Online purchase',
        'subtitle': 'E-commerce',
        'amount': -45.90,
        'currency': 'EUR',
      },
      {
        'title': 'Wallet top-up',
        'subtitle': 'Bank transfer',
        'amount': 500.00,
        'currency': 'EUR',
      },
    ];
  }

  Future<void> sendMoney({
    required String method,
    required String destination,
    required double amount,
  }) async {
    // TODO: Call /transfer endpoint.
  }

  Future<void> startKyc() async {
    // TODO: Trigger KYC flow with provider.
  }
}
