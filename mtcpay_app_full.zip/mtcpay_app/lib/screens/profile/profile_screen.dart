import 'package:flutter/material.dart';

import '../../routes/app_routes.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  void _openKyc(BuildContext context) {
    Navigator.of(context).pushNamed(AppRoutes.kyc);
  }

  void _openSettings(BuildContext context) {
    Navigator.of(context).pushNamed(AppRoutes.settings);
  }

  void _openSupport(BuildContext context) {
    Navigator.of(context).pushNamed(AppRoutes.support);
  }

  void _openLegal(BuildContext context) {
    Navigator.of(context).pushNamed(AppRoutes.legal);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const ListTile(
            title: Text('Full name'),
            subtitle: Text('John Doe'),
          ),
          const ListTile(
            title: Text('KYC status'),
            subtitle: Text('Verified'),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.verified_user_outlined),
            title: const Text('KYC verification'),
            onTap: () => _openKyc(context),
          ),
          ListTile(
            leading: const Icon(Icons.settings_outlined),
            title: const Text('Settings'),
            onTap: () => _openSettings(context),
          ),
          ListTile(
            leading: const Icon(Icons.support_agent),
            title: const Text('Support'),
            onTap: () => _openSupport(context),
          ),
          ListTile(
            leading: const Icon(Icons.gavel_outlined),
            title: const Text('Legal & terms'),
            onTap: () => _openLegal(context),
          ),
        ],
      ),
    );
  }
}
