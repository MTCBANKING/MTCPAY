import 'package:flutter/material.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
      ),
      body: ListView(
        children: const [
          ListTile(
            leading: Icon(Icons.notifications),
            title: Text('Payment successful'),
            subtitle: Text('Your card payment of €19.99 was approved.'),
          ),
          ListTile(
            leading: Icon(Icons.info_outline),
            title: Text('KYC approved'),
            subtitle: Text('Your identity verification has been approved.'),
          ),
        ],
      ),
    );
  }
}
