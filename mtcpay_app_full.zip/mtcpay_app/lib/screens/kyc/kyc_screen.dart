import 'package:flutter/material.dart';

class KycScreen extends StatelessWidget {
  const KycScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('KYC verification'),
      ),
      body: Stepper(
        steps: const [
          Step(
            title: Text('Personal details'),
            content: Text('Collect user full name, date of birth and address.'),
            isActive: true,
          ),
          Step(
            title: Text('Documents'),
            content: Text('Upload ID document and proof of address.'),
            isActive: false,
          ),
          Step(
            title: Text('Selfie'),
            content: Text('Capture a selfie for liveness / face match.'),
            isActive: false,
          ),
        ],
      ),
    );
  }
}
