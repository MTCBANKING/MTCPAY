import 'package:flutter/material.dart';

class LegalScreen extends StatelessWidget {
  const LegalScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Legal & terms'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          Text(
            'MTCPAY is a digital financial services platform. '
            'It does not operate as a bank and does not accept public deposits.\n',
          ),
          Text(
            'Services are provided in cooperation with licensed payment and/or e-money institutions, '
            'in line with the applicable regulations.',
          ),
        ],
      ),
    );
  }
}
