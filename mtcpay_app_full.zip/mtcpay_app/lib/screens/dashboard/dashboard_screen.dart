import 'package:flutter/material.dart';

import '../../routes/app_routes.dart';
import '../../widgets/card_tile.dart';
import '../../widgets/transaction_tile.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _currentIndex = 0;

  void _onTapNav(int index) {
    setState(() => _currentIndex = index);
    switch (index) {
      case 0:
        Navigator.of(context).pushReplacementNamed(AppRoutes.dashboard);
        break;
      case 1:
        Navigator.of(context).pushReplacementNamed(AppRoutes.wallet);
        break;
      case 2:
        Navigator.of(context).pushReplacementNamed(AppRoutes.cards);
        break;
      case 3:
        Navigator.of(context).pushReplacementNamed(AppRoutes.transactions);
        break;
      case 4:
        Navigator.of(context).pushReplacementNamed(AppRoutes.profile);
        break;
    }
  }

  void _openAddMoney() {
    Navigator.of(context).pushNamed(AppRoutes.addMoney);
  }

  void _openSendMoney() {
    Navigator.of(context).pushNamed(AppRoutes.sendMoney);
  }

  void _openNotifications() {
    Navigator.of(context).pushNamed(AppRoutes.notifications);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
        actions: [
          IconButton(
            onPressed: _openNotifications,
            icon: const Icon(Icons.notifications_outlined),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Wallet balance',
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 8),
          const Text(
            '€ 1,250.00',
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _openAddMoney,
                  icon: const Icon(Icons.add),
                  label: const Text('Add money'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _openSendMoney,
                  icon: const Icon(Icons.send),
                  label: const Text('Send'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          const Text(
            'Your cards',
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 120,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: const [
                CardTile(
                  last4: '1234',
                  label: 'MTCPAY Virtual',
                ),
                CardTile(
                  last4: '5678',
                  label: 'MTCPAY Physical',
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'Recent transactions',
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 8),
          const TransactionTile(
            title: 'Online purchase',
            subtitle: 'E-commerce',
            amount: '-€ 45.90',
          ),
          const TransactionTile(
            title: 'Wallet top-up',
            subtitle: 'Bank transfer',
            amount: '+€ 500.00',
          ),
          const TransactionTile(
            title: 'Card payment',
            subtitle: 'POS',
            amount: '-€ 19.99',
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: _onTapNav,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.dashboard), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.account_balance_wallet), label: 'Wallet'),
          BottomNavigationBarItem(icon: Icon(Icons.credit_card), label: 'Cards'),
          BottomNavigationBarItem(icon: Icon(Icons.swap_horiz), label: 'Activity'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}
